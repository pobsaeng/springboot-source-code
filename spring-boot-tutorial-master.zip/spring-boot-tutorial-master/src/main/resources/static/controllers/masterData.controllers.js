'use strict';

angular.module('appDoCFD')

    .controller('masterDataCtrl', ['$scope', '$rootScope', 'masterDataAPI', 'saveFormDataSvc' ,
			function($scope, $rootScope, masterDataAPI, saveFormDataSvc) {

    }]);
	